#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<time.h>
int binarysearch(int a[],int key,int first,int last)
{
    int mid;
    while(first<=last)
    {
        int mid;
        mid=(first+last)/2;
        if(key==a[mid])
        return mid+1;
        else if (key<a[mid])
        last=mid-1;
        else
        first=mid+1;
    }
    return-1;
}
void main()
{
    char ch;
    int a[100],n,key,i,res,first,last;
    double time_taken;
    clock_t st,et;
    clrscr();
    printf("Enter the Number of elements in Array: \n");
    scanf("%d",&n);
    printf("Enter the Element of Array:\n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    printf("Enter the key Element to search:\n");
    scanf("%d",&key);
    first=0;
    last=n-1;
    st=clock();
    res=binarysearch(a,key,first,last);
    et=clock();
    time_taken=((et-st)/(CLOCKS_PER_SEC))*1000;
    if(res==-1)
    {
        printf("The Search element is not found\n");
        printf("The Execution Time is= %d of Milliseconds",time_taken);
    }
    else
    printf("The Search Element is found at %d \n",res);
    printf("The Execution Time is = %d of Milliseconds",time_taken);
    getch();
}
