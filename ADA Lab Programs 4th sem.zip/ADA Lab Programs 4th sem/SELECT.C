#include <stdio.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>
void selectionsort(int a[])
{
    int i, j, pos, small, temp;
    for (i = 0; i < (10 - 1); i++)
    {
        small = a[i];
        pos = i;
        for (j = (i + 1); j < 10; j++)        
        {
            if (a[j] < small)
            {
                small = a[j];
                pos = j;
            }
        }
        temp = a[pos];
        a[pos] = a[i];
        a[i] = temp;
    }
}
void main()
{
    int n, i, a[10];
    double time_taken;
    clock_t st, et;
    clrscr();
    printf(" Random Unsorted Array\n");
    for (i = 0; i < 10; i++)
    {
        n = rand() % 50 + 1;
        printf("%d\n", n);
        a[i] = n;
    }
    st = clock();
    selectionsort(a);
    et = clock();
    time_taken = ((et - st) / CLOCKS_PER_SEC) * 1000;
    printf("The Sorted Elements are\n");
    for (i = 0; i < 10; i++)
        printf("%d\n", a[i]);
    printf("The Execution Time is = %d of Milliseconds", time_taken);
    getch();
}
