#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
void main()
{
     int n;
     double time_taken;
     clock_t st,et;
     void tower(int,char,char,char);
     clrscr();
     printf("Enter the number of disks\n");
     scanf("%d",&n);
     st=clock();
     et=clock();
     time_taken=((et-st)/CLOCKS_PER_SEC)*1000;
     printf("Movement of Disks are \n");
     tower(n,'A','B','C');
     printf("The Execution time is=%d of milliseconds",time_taken);
     getch();
}
void tower(int n,char s,char t,char d)
{
     if(n==1)
     {
          printf("Move%d from %c to %c\n",n,s,d);
          return;     
     }
tower(n-1,s,d,t);
printf("Move %d from %c to %c\n",n,s,d);
tower(n-1,t,s,d);

}