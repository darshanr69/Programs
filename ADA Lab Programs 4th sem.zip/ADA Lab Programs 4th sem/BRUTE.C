#include <stdio.h>
#include <conio.h>
long power(int a, int n)
{
    if (n == 0)
        return 1;
    else
        return (a * power(a, n - 1));
}
long power1(int a, int n)
{
    if (n == 0)
        return 1;
    if (a == 0)
        return 0;
    if (n % 2 == 0)
        return power1(a * a, n / 2);
    else
        return (a * power1(a * a, n / 2));
}
void main()
{
    int a, n, bf, dc;
    clrscr();
    printf("Enter a and n:\n");
    scanf("%d%d", &a, &n);
    bf = power(a, n);
    dc = power1(a, n);
    printf("Bruteforce Method %d: \n", bf);
    printf("Divide and Conquer Method %d: \n", dc);
    getch();
}