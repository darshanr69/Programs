#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int binary_search(int *arr, int low, int high, int key)
{
    while (low <= high)
    {
        int mid = low + (high - low) / 2;
        if (arr[mid] == key)
        {
            return mid;
        }

        if (arr[mid] < key)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }
    return -1;
}
int main()
{
    int n, i, key;
    printf("Enter the Number of Elements: ");
    scanf("%d", &n);
    int *arr = malloc(n * sizeof(int));
    printf("\n Enter the Elements of an Array in Ascending Order: ");
    for (i = 0; i < n; i++)
        scanf("%d", &arr[i]);
    printf("\n Enter the Key Element to be Searched: ");
    scanf("%d", &key);

    int repeat = 1000000;
    int result;

    clock_t start = clock();
    for (i = 0; i < repeat; i++)
    {
        result = binary_search(arr, 0, n - 1, key);
    }
    clock_t end = clock();

    if (result != -1)
    {
        printf("Key %d Found at Position %d", key, result);
    }
    else
    {
        printf("Key %d Not Found", key);
    }
    double time_taken = ((double)end - start) / CLOCKS_PER_SEC * 1000;
    printf("\n Time Taken to Search a Key Element = %f Milliseconds \n", time_taken);
    return 0;
}