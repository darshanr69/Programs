#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<time.h>
int linearsearch(int a[],int n,int key)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(key==a[i])
        return i;}return-1;
}
void main()
{
    char ch;
    int a[100],n,key,i,res;
    clock_t st,et;
    double time_taken;
    clrscr();
    printf("Enter the Number of Elements in an Array\n");
    scanf("%d",&n);
    printf("Enter the Elements of Array: \n");
    for(i=0;i<n;i++)
    scanf("%d",&a[i]);
    printf("Enter the Elements to Search: \n");
    scanf("%d",&key);
    st=clock();
    res=linearsearch(a,n,key);
    et=clock();
    time_taken=(et-st/CLOCKS_PER_SEC)*1000;
    if(res==1)
    {
        printf("The Search element is not found \n");
        printf("The Execution time is=%d of Milliseconds",time_taken);
    }
    else
    printf("The Search Element is found at position %d\n",res+1);
    printf("The Execution time is = %d of Milliseconds",time_taken);
    getch();
}
