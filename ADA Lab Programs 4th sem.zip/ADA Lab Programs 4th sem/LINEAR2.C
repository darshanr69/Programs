#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int linear_search(int arr[], int n, int key)
{
    for (int i = 0; i < n; i++)
    {
        if (arr[i] == key)
        {
            return i;
        }
    }
    return -1;
}

int main()
{
    int n, key,arr[100];
    printf("ENTER THE NUMBER OF ELEMENTS: ");
    scanf("%d", &n);

    //int *arr =(int*) malloc(n * sizeof(int));
    printf("ENTER THE ELEMENTS OF THE ARRAY: ");
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    printf("ENTER THE KEY ELEMENT TO BE SEARCHED: ");
    scanf("%d", &key);

    int repeat = 1000000;
    int result;
    
    clock_t start = clock();
    for (int i = 0; i < repeat; i++)
    {
        result = linear_search(arr, n, key);
    }
    clock_t end = clock();

    if (result == -1)
    {
        printf("Key %d Not Found\n", key);
    }
    else
    {
        printf("Key %d Found at index %d\n", key, result);
    }

    float time_taken = ((float)(end - start)) / CLOCKS_PER_SEC * 1000;
    printf("Time Taken To Search an Element = %f milliseconds\n", time_taken);

   // free(arr); // Free the dynamically allocated memory

    return 0;
}
